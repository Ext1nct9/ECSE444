int KalmanFilterCMSIS(float* InputArray, float* OutputArray, struct kalman_state * kstate, int length);
