void calculateDiff(float originalArray[], float calculatedArray[], float differenceArray[],int length);

float calculateAvg(float differenceArray[], int length);

float calculateStDev(float differenceArray[], float mean, int length);

void calculateCorrelation(float originalArray[], float calculatedArray[], float correlationArray[],int length);

void calculateConvolution(float originalArray[], float calculatedArray[], float resultArray[], int length);



